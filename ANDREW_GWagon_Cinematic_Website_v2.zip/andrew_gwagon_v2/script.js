import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const $ = (selector) => document.querySelector(selector);
const preloader = $('#preloader');
const menuToggle = $('#menuToggle');
const mobileMenu = $('#mobileMenu');

window.addEventListener('load', () => setTimeout(() => preloader?.classList.add('done'), 500));
$('#year').textContent = new Date().getFullYear();
menuToggle.addEventListener('click', () => {
  const open = mobileMenu.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
mobileMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mobileMenu.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

// Simple reveal animation that also works if GSAP is unavailable.
const revealObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

const canvas = $('#carCanvas');
const stageLoading = $('#stageLoading');
const progressBar = $('#explosionProgress');
const stageStatus = $('#stageStatus');
const explodeButton = $('#explodeButton');

let scene, camera, renderer, controls, carParts = [], explodeTimeline;
let isExploded = false;
let scrollProgress = 0;
let animationFrame;

function material(color, roughness = 0.55, metalness = 0.25) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness });
}
const paint = material('#56635a', 0.32, 0.68);
const darkPaint = material('#202723', 0.42, 0.45);
const glass = new THREE.MeshPhysicalMaterial({ color: '#182321', roughness: 0.12, metalness: 0.25, transparent: true, opacity: 0.83, clearcoat: 1 });
const rubber = material('#111412', 0.9, 0.02);
const metal = material('#a8aea4', 0.28, 0.8);
const lamp = new THREE.MeshStandardMaterial({ color: '#e8f1d8', emissive: '#b8d58b', emissiveIntensity: 0.75, roughness: 0.2 });
const grilleMat = material('#111512', 0.38, 0.55);

function addPart(name, geometry, mat, position, rotation = [0, 0, 0], explode = [0, 0, 0]) {
  const group = new THREE.Group();
  group.name = name;
  group.position.set(...position);
  group.userData.assembled = new THREE.Vector3(...position);
  group.userData.exploded = new THREE.Vector3(position[0] + explode[0], position[1] + explode[1], position[2] + explode[2]);
  const mesh = new THREE.Mesh(geometry, mat);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.rotation.set(...rotation);
  group.add(mesh);
  scene.add(group);
  carParts.push(group);
  return group;
}

function addBox(name, size, mat, pos, explode, bevel = false) {
  // A crisp boxy silhouette is intentional: this is a stylised concept vehicle.
  const geometry = new THREE.BoxGeometry(...size);
  return addPart(name, geometry, mat, pos, [0, 0, 0], explode);
}

function buildVehicle() {
  // Chassis and underbody
  addBox('ladder chassis', [2.0, 0.22, 4.1], darkPaint, [0, 0.72, 0], [0, -0.75, 0]);
  addBox('lower body shell', [2.18, 0.82, 4.0], paint, [0, 1.22, 0], [0, 0.15, 0]);
  addBox('bonnet', [2.12, 0.18, 1.12], paint, [0, 1.76, 1.38], [0, 0.65, 0.35]);
  addBox('roof panel', [1.92, 0.16, 2.05], darkPaint, [0, 2.78, -0.25], [0, 0.95, 0]);
  // Cabin pillars and glass panels
  addBox('front windscreen', [1.78, 0.78, 0.07], glass, [0, 2.27, 0.92], [0, 0.55, 0.5], true).rotation.x = -0.12;
  addBox('rear glass', [1.78, 0.72, 0.07], glass, [0, 2.26, -1.36], [0, 0.55, -0.45], true).rotation.x = 0.1;
  addBox('left side glass', [0.07, 0.72, 1.95], glass, [-0.99, 2.28, -0.22], [-0.42, 0.5, 0]);
  addBox('right side glass', [0.07, 0.72, 1.95], glass, [0.99, 2.28, -0.22], [0.42, 0.5, 0]);
  // Four separated doors
  addBox('left front door', [0.1, 0.75, 1.0], paint, [-1.105, 1.65, 0.62], [-0.95, 0.05, 0.15]);
  addBox('right front door', [0.1, 0.75, 1.0], paint, [1.105, 1.65, 0.62], [0.95, 0.05, 0.15]);
  addBox('left rear door', [0.1, 0.75, 0.95], paint, [-1.105, 1.65, -0.47], [-1.05, 0.05, -0.15]);
  addBox('right rear door', [0.1, 0.75, 0.95], paint, [1.105, 1.65, -0.47], [1.05, 0.05, -0.15]);
  // Front fascia, grille, bumpers, lamps
  addBox('front grille', [0.8, 0.48, 0.08], grilleMat, [0, 1.38, 2.04], [0, 0.05, 0.45]);
  addBox('front bumper', [2.25, 0.2, 0.28], metal, [0, 0.88, 2.12], [0, -0.55, 0.65]);
  addBox('rear bumper', [2.25, 0.2, 0.28], metal, [0, 0.88, -2.1], [0, -0.55, -0.65]);
  addBox('left headlamp', [0.28, 0.2, 0.1], lamp, [-0.78, 1.67, 2.06], [-0.45, 0.15, 0.4]);
  addBox('right headlamp', [0.28, 0.2, 0.1], lamp, [0.78, 1.67, 2.06], [0.45, 0.15, 0.4]);
  // Wheels with metallic hubs. Wheels are their own exploded groups.
  const wheelPositions = [[-1.15, 0.68, 1.35], [1.15, 0.68, 1.35], [-1.15, 0.68, -1.35], [1.15, 0.68, -1.35]];
  wheelPositions.forEach((pos, i) => {
    const wheelGroup = new THREE.Group();
    wheelGroup.name = `wheel ${i + 1}`;
    wheelGroup.position.set(...pos);
    wheelGroup.userData.assembled = new THREE.Vector3(...pos);
    const side = pos[0] < 0 ? -1 : 1;
    wheelGroup.userData.exploded = new THREE.Vector3(pos[0] + side * 0.85, pos[1] - 0.2, pos[2] + (pos[2] > 0 ? 0.15 : -0.15));
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(0.54, 0.54, 0.34, 40), rubber);
    tire.rotation.z = Math.PI / 2;
    tire.castShadow = true;
    wheelGroup.add(tire);
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.36, 32), metal);
    hub.rotation.z = Math.PI / 2;
    wheelGroup.add(hub);
    const center = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.38, 24), darkPaint);
    center.rotation.z = Math.PI / 2;
    wheelGroup.add(center);
    scene.add(wheelGroup);
    carParts.push(wheelGroup);
  });
  // Small roof details and side mirrors
  addBox('roof light bar', [0.95, 0.08, 0.08], metal, [0, 2.9, 0.72], [0, 1.25, 0.4]);
  addBox('left mirror', [0.18, 0.18, 0.28], darkPaint, [-1.22, 2.0, 0.75], [-0.65, 0.2, 0.35]);
  addBox('right mirror', [0.18, 0.18, 0.28], darkPaint, [1.22, 2.0, 0.75], [0.65, 0.2, 0.35]);
}

function initThree() {
  if (!canvas) return;
  try {
    scene = new THREE.Scene();
    scene.background = new THREE.Color('#29312b');
    camera = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
    camera.position.set(7.2, 5.1, 8.6);
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.8));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;

    const hemi = new THREE.HemisphereLight('#f1f5e9', '#242b25', 2.0);
    scene.add(hemi);
    const key = new THREE.DirectionalLight('#fff5df', 3.1);
    key.position.set(5, 9, 6);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    scene.add(key);
    const rim = new THREE.DirectionalLight('#c5e5a0', 2.2);
    rim.position.set(-6, 4, -5);
    scene.add(rim);
    const fill = new THREE.PointLight('#9eafa0', 1.1, 30);
    fill.position.set(0, 2, 5);
    scene.add(fill);

    const floor = new THREE.Mesh(new THREE.CircleGeometry(12, 64), new THREE.MeshStandardMaterial({ color: '#29312b', roughness: 0.86 }));
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.04;
    floor.receiveShadow = true;
    scene.add(floor);
    const grid = new THREE.GridHelper(16, 32, '#65715f', '#3e493f');
    grid.position.y = -0.025;
    grid.material.transparent = true;
    grid.material.opacity = 0.14;
    scene.add(grid);

    buildVehicle();
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.055;
    controls.enablePan = false;
    controls.minDistance = 6;
    controls.maxDistance = 14;
    controls.minPolarAngle = 0.45;
    controls.maxPolarAngle = 1.42;
    controls.target.set(0, 1.3, 0);
    controls.autoRotate = true;
    controls.autoRotateSpeed = 0.45;
    resizeRenderer();
    stageLoading.classList.add('hidden');
    setupExplosionMotion();
    animate();
  } catch (error) {
    console.error('3D scene could not start:', error);
    stageLoading.innerHTML = '3D VIEW NEEDS WEBGL<br><span>TRY A CURRENT VERSION OF CHROME OR EDGE</span>';
  }
}

function resizeRenderer() {
  if (!renderer || !camera) return;
  const rect = canvas.getBoundingClientRect();
  const width = Math.max(1, rect.width);
  const height = Math.max(1, rect.height);
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
}

function setExplode(progress) {
  const p = THREE.MathUtils.clamp(progress, 0, 1);
  carParts.forEach(part => {
    const from = part.userData.assembled;
    const to = part.userData.exploded || from;
    part.position.lerpVectors(from, to, p);
  });
  progressBar.style.width = `${p * 100}%`;
  stageStatus.textContent = p > 0.55 ? '02 — COMPONENTS SEPARATED' : p > 0.05 ? '01.5 — EXPLORING THE STRUCTURE' : '01 — ASSEMBLED FORM';
  explodeButton.innerHTML = p > 0.5 ? 'Reassemble view <span>↙</span>' : 'Explode view <span>↗</span>';
  isExploded = p > 0.5;
}

function setupExplosionMotion() {
  // Scroll progress drives the exploded assembly, while the button offers a direct toggle.
  if (window.gsap && window.ScrollTrigger) {
    gsap.registerPlugin(ScrollTrigger);
    ScrollTrigger.create({
      trigger: '#stageWrap',
      start: 'top 72%',
      end: 'bottom 45%',
      scrub: 0.7,
      onUpdate: self => {
        scrollProgress = self.progress;
        setExplode(scrollProgress);
      }
    });
  }
  explodeButton.addEventListener('click', () => {
    const target = isExploded ? 0 : 1;
    const start = scrollProgress;
    const duration = 700;
    const startTime = performance.now();
    const ease = t => 1 - Math.pow(1 - t, 3);
    function step(now) {
      const t = Math.min(1, (now - startTime) / duration);
      const value = start + (target - start) * ease(t);
      scrollProgress = value;
      setExplode(value);
      if (t < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  });
}

function animate() {
  animationFrame = requestAnimationFrame(animate);
  if (controls) controls.update();
  if (renderer && scene && camera) renderer.render(scene, camera);
}

window.addEventListener('resize', resizeRenderer);
window.addEventListener('beforeunload', () => cancelAnimationFrame(animationFrame));
initThree();
