@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  start "ANDREW website server" cmd /k py -m http.server 8000
  timeout /t 2 >nul
  start http://localhost:8000
  exit /b
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "ANDREW website server" cmd /k python -m http.server 8000
  timeout /t 2 >nul
  start http://localhost:8000
  exit /b
)
echo Python was not found. Please open this folder in Visual Studio Code and use the Live Server extension.
pause
