ANDREW — G-CLASS INSPIRED CINEMATIC WEBSITE (VERSION 2)

WHAT IS INCLUDED
- index.html: page structure
- styles.css: visual design and responsive laptop/mobile layout
- script.js: Three.js 3D concept vehicle, scroll-driven exploded view, interactions

IMPORTANT
This is an independent ANDREW concept, not an official Mercedes-Benz website or vehicle model. The 3D SUV is built from original geometric shapes in code. It is a stylised G-Class-inspired concept, not an exact licensed G-Wagon model.

HOW TO RUN ON WINDOWS (BEGINNER FRIENDLY)
The 3D module uses browser imports, so do not open index.html by double-clicking it. Run it through a small local web server.

OPTION A — VS CODE + LIVE SERVER (recommended)
1. Extract the ZIP to a folder you can find, such as Desktop\ANDREW.
2. Open Visual Studio Code.
3. Click File > Open Folder, then select the extracted ANDREW folder.
4. In VS Code, click Extensions (the four-square icon on the left).
5. Search for "Live Server" and install the extension by Ritwick Dey.
6. In the file list, right-click index.html.
7. Click "Open with Live Server".
8. Your browser should open the site. Keep VS Code open while using it.

OPTION B — INCLUDED WINDOWS START FILE
Double-click start-andrew.bat. If Python is installed, it starts a local server and opens the site in your browser. If it says Python is missing, use Option A.

INTERNET
An internet connection is required for the Three.js and GSAP libraries loaded from a CDN, and for Google Fonts. The core HTML/CSS/JS files are included in this ZIP.

PHONE TEST
After starting the site with Live Server, use the same Wi-Fi network and your computer's local IP address with port 5500 to test on a phone. For example: http://192.168.1.5:5500. Your firewall may ask whether to allow local network access.

NEXT UPGRADE
For a photorealistic exploded G-Wagon with individually modelled OEM components, replace the stylised code-built concept with a licensed GLB/GLTF model that permits web use and part separation.
